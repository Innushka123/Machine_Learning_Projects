import requests
import os
import pandas as pd
from collections import Counter

url = "https://raw.githubusercontent.com/aalanwar/Logical-Zonotope/refs/heads/main/README.md"
response = requests.get(url)
folder = os.path.expanduser("~/Documents/AML/AML_Assignment_1")

# os.makedirs(folder, exist_ok=True)

path = os.path.join(folder, "README.txt")

if response.status_code == 200:
    with open(path, "w") as file:
        file.write(response.text)
    print(f"File saved as {path}")
else:
    print(f"Failed to download the file. Status code: {response.status_code}")
    
def count_uniq_words(file_path):
    file = open(file_path, 'r')
    words = file.read().lower().split() 
    amount_words = Counter(words)
    file.close()
    return amount_words

print(count_uniq_words(path))